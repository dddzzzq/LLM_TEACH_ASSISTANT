import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args){
        try {
            BookMethod method = (BookMethod)Naming.lookup("rmi://localhost:8989/BookMethod");
            method.initData();
            Scanner input = new Scanner(System.in);
            System.out.println(menu());
            int choice = input.nextInt();
            while (choice!=0){
                switch (choice){
                    case 1: System.out.println("please input bookID and bookName to add it\n");;
                            int newBookID = input.nextInt();
                            String newName = input.next();
                            Book newBook = new Book(newBookID,newName);
                            if (method.add(newBook)){
                                System.out.println("add a new book sucessfully\n");
                            }
                            else {
                                System.out.println("ID:" + newBookID + " has existed, add book failed\n");
                            }
                            break;
                    case 2: System.out.println("please input bookID to query it\n");
                            int queryBookID = input.nextInt();
                            Book queryid = method.queryByID(queryBookID);
                            if (queryid!=null){
                                System.out.println("*******book list *********\n");
                                queryid.showInfo();
                            }else {
                                System.out.println("this book isn't existing");
                            }
                            break;
                    case 3: System.out.println("please input bookName to query it\n");
                            String queryBookKeyword = input.next();
                            BookList list = method.queryByName(queryBookKeyword);
                            if (!list.booklist.isEmpty()){
                                System.out.println("*******book list *********\n");
                                list.showInfo();
                            }else {
                                System.out.println("this book isn't existing");
                            }
                            break;
                    case 4: System.out.println("please input bookID to delete it\n");
                            int deleteID = input.nextInt();
                            if(method.delete(deleteID)){
                                System.out.println("delete sucessfully\n");
                            }else {
                                System.out.println("delete failed\n");
                            }
                            break;
                    case 5: System.out.println(method.booksInfo());
                            break;
                    default:System.out.println(menu());
                            break;
                }
                choice = input.nextInt();
            }
        } catch (NotBoundException | FileNotFoundException | MalformedURLException | RemoteException e) {
            e.printStackTrace();
        }
    }

    private static String menu() {
        return "**********menu**********\n"
                + "1.add book\n"
                + "2.query Book by ID\n"
                + "3.query Book By Name\n"
                + "4.delete Book by ID\n"
                + "5.show All Books\n"
                + "0.quit\n"
                + "************************\n";
    }
}
