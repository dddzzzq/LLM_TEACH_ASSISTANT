import java.io.Serializable;

public class Book implements Serializable {
    private static final long serialVersionUID = 42L;

    private String book_name;
    private int book_id;

    public Book(int id, String name) {
        this.book_name = name;
        this.book_id = id;
    }
    public int getId(){
        return book_id;
    }
    public String getName(){
        return book_name;
    }
    public String getInfo(){
        return "ID:" + book_id + " name:" + book_name + "\n";
    }
    public void showInfo(){
        System.out.println(getInfo());
    }
}