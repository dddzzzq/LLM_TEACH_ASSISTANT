import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;


public class Server {
    public static void main(String[] args) throws Exception {

        try {
            BookMethod mserver = new BookMethodImpl();
            LocateRegistry.createRegistry(8989);
            Naming.bind("rmi://localhost:8989/BookMethod",mserver);
            System.out.println("Registering Calculator Object");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

