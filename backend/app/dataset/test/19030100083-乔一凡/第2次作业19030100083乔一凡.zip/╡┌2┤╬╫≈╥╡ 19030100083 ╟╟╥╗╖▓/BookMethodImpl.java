import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;

public class BookMethodImpl extends UnicastRemoteObject implements BookMethod{

    BookMethodImpl() throws RemoteException {
        super();
    }
    ArrayList<Book> books = new ArrayList<>();


    @Override
    public void initData() throws RemoteException, FileNotFoundException{
        File file = new File("D:\\Projects\\ClientServer\\src\\content.txt");
        Scanner input = new Scanner(file);
        while (input.hasNext()){
            int id = input.nextInt();
            String name = input.next();
            books.add(new Book(id,name));
        }
        input.close();
    }
    @Override
    public void update() throws RemoteException,FileNotFoundException{
        File file = new File("D:\\Projects\\ClientServer\\src\\content.txt");
        PrintWriter output = new PrintWriter(file);
        for (int i=0;i<books.size();i++){
            output.print(books.get(i).getId()+" ");
            output.println(books.get(i).getName());
        }
        output.close();
    }
    @Override
    public boolean add(Book b) throws RemoteException,FileNotFoundException{
        for (int i=0;i<books.size();i++){
            if(books.get(i).getId()==b.getId()){
                return false;
            }
        }
        books.add(b);
        update();
        return true;
    }
    @Override
    public Book queryByID(int bookID) throws RemoteException{
        Book b = null;
        for (int i=0;i<books.size();i++){
            if (books.get(i).getId()==bookID){
                b = books.get(i);
                return b;
            }
        }
        return null;
    }
    @Override
    public BookList queryByName (String name) throws RemoteException{
        BookList query = new BookList();
        for (int i=0;i<books.size();i++){
            Book a = books.get(i);
            if(a.getName().equals(name)){
                query.booklist.add(a);
            }
        }
        return query;
    }
    @Override
    public boolean delete(int bookID) throws RemoteException,FileNotFoundException{
        for (int i=0;i<books.size();i++){
            if (books.get(i).getId()==bookID){
                books.remove(books.get(i));
                update();
                return true;
            }
        }
        return false;
    }
    @Override
    public String booksInfo() throws RemoteException{
        String info = "*******current books********\n";
        for (int i=0;i<books.size();i++){
            info += ("ID:"+books.get(i).getId()+" name:"+ books.get(i).getName()+"\n");
        }
        return info;
    }
    /*@Override
    public void showAllTheBooks() throws RemoteException{
        System.out.println(booksInfo());
    }*/
}